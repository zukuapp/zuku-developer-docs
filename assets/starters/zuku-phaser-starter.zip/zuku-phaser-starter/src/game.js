/* ZUKU Phaser starter. Phaser 3.90.0 is included with its MIT license. */
(() => {
  class Runner extends Phaser.Scene {
    create() {
      this.over = false; this.points = 0; this.speed = 260;
      this.add.rectangle(400, 225, 800, 450, 0x111a2d);
      const ground = this.add.rectangle(400, 430, 800, 40, 0x24374b);
      this.physics.add.existing(ground, true);
      this.player = this.add.rectangle(96, 380, 30, 38, 0xffd600);
      this.physics.add.existing(this.player); this.player.body.setCollideWorldBounds(true);
      this.physics.add.collider(this.player, ground);
      this.blocks = this.physics.add.group({ allowGravity: false, immovable: true });
      this.physics.add.collider(this.player, this.blocks, () => this.lose());
      this.time.addEvent({ delay: 1500, loop: true, callback: () => {
        if (this.over) return; const height = Phaser.Math.Between(26, 50);
        const block = this.add.rectangle(825, 410 - height / 2, 22, height, 0xec008c);
        this.blocks.add(block); block.body.setAllowGravity(false).setImmovable(true).setVelocityX(-this.speed);
      }});
      this.input.keyboard.on('keydown-SPACE', event => { event.preventDefault(); this.jump(); });
      this.input.keyboard.on('keydown-UP', event => { event.preventDefault(); this.jump(); });
      this.input.on('pointerdown', () => this.jump());
      window.__zukuStarter = { engine: 'phaser', getState: () => ({ over: this.over, score: Math.floor(this.points), y: this.player.y }), jump: () => this.jump(), forceLoss: () => this.lose() };
      document.getElementById('score').textContent = 'Score 0';
      document.getElementById('instructions').textContent = 'Press Space or tap to jump. After a collision, tap to restart.';
    }
    jump() { if (this.over) { this.scene.restart(); return; } if (this.player.body.blocked.down || this.player.body.touching.down) this.player.body.setVelocityY(-610); }
    lose() { if (this.over) return; this.over = true; this.physics.pause(); document.getElementById('instructions').textContent = 'Game over. Press Space or tap to restart.'; }
    update(_time, delta) { if (this.over) return; this.points += delta / 100; this.speed += delta / 1500; document.getElementById('score').textContent = `Score ${Math.floor(this.points)}`; this.blocks.getChildren().forEach(block => { if (block.x < -40) block.destroy(); }); }
  }
  new Phaser.Game({ type: Phaser.CANVAS, width: 800, height: 450, parent: 'game', backgroundColor: '#111a2d', physics: { default: 'arcade', arcade: { gravity: { y: 1800 }, debug: false } }, scale: { mode: Phaser.Scale.FIT, autoCenter: Phaser.Scale.CENTER_BOTH }, scene: Runner });
})();
