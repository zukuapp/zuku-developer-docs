# zuku-phaser-starter

A Phaser 3.90.0 jump runner with the local engine and MIT license included.

## Run / 실행

```sh
cd zuku-phaser-starter
zuku run
```

Open the local URL. Press Space or tap to jump. Ctrl+C stops the preview.
표시된 로컬 주소를 열고 스페이스바 또는 탭으로 점프하세요. Ctrl+C로 미리보기를 종료합니다.

## Check and package / 검사와 패키징

```sh
zuku validate .
zuku package . --format zwf
```

Change src/game.js and restart zuku run to view the new snapshot.
src/game.js를 수정하고 zuku run을 다시 실행하세요.

ZUKU CLI: https://docs.zuzunza.com/
